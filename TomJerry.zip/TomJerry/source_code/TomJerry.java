package com.fakeplayer.reverse;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

public class TomJerry {
    public static void Exec(Context context) {
        Toast.makeText(context, "Mᴏᴅᴅᴇᴅ Bʏ Rᴇᴠᴇʀsᴇ", Toast.LENGTH_SHORT).show();
        String[] coin = new String[] {
                "saved_my_coins",
                "9999"
        };
        String[] crystals = new String[] {
                "saved_my_crystals",
                "9999"
        };

        SharedPreferences sp = context.getSharedPreferences("Cocos2dxPrefsFile", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();

        if (sp.getInt(coin[0],0) < Integer.parseInt(coin[1])){
            ed.putInt(coin[0], Integer.parseInt(coin[1]));
        }
        if (sp.getInt(crystals[0],0) < Integer.parseInt(crystals[1])){
            ed.putInt(crystals[0], Integer.parseInt(crystals[1]));
        }
        ed.apply();
    }
}
