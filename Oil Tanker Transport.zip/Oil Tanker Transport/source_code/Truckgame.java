package com.fakeplayer.reverse;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

public class Truckgame {

    /**
    HOW TO USE??

    Truckgame tgame = new Truckgame(this); //oncreate
        tgame.Coin(); //apply unlimited coins
        tgame.Cars(); //unlock all cars
        tgame.Levels(); //unlock all levels

    */

    private static SharedPreferences sp;
    private static SharedPreferences.Editor ed;

    public Truckgame(Context context) {
        Toast.makeText(context, "Mᴏᴅᴅᴇᴅ Bʏ Rᴇᴠᴇʀsᴇ", Toast.LENGTH_SHORT).show();

        StringBuilder builder = new StringBuilder();
        builder.append(context.getPackageName());
        builder.append(".v2.playerprefs");

        sp = context.getSharedPreferences(builder.toString(), Context.MODE_PRIVATE);
        ed = sp.edit();
    }

    public static void Coin() {
        int newCoin = 1000000000;
        int readCoin = sp.getInt("totalcoins",0);
        if (readCoin < newCoin) {
            ed.putInt("totalcoins",newCoin);
        }
        ed.apply();
    }

    public static void Cars() {
        for (int i = 1; i <= 10; i++) {
            ed.putInt("PurchasedTruck"+i,1); //truck
            ed.putInt("unlock"+i,1);
        }
        for (int i = 1; i <= 4; i++) {
            ed.putInt("Purchased"+i,1); //oil truck
            ed.putInt("trailer"+i,1);
        }

        ed.apply();
    }

    public static void Levels() {
        ed.putInt("LevelsMountain",11); //max level -1 (12-1 == 11)
        ed.putInt("levels",21);
        ed.putInt("SchoolDriveModelevels",19);
        ed.apply();
    }





}
